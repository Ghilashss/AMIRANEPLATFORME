// Configuration globale
export const CONFIG = {
    DATE_FORMAT: 'fr-FR',
    CURRENCY: 'DZD',
    CURRENCY_DISPLAY: 'DA',
    API_URL: 'http://localhost:1000'
};